module.exports = { plugins: { tailwindcss: {} } };
